<?php
echo 'working';
$token = "6740519053:AAH3M72-OemEsi3XxhzxPpzNNHcXZ6BZrDk";
$botu = "converter_cryptobot";
$bot = json_decode(file_get_contents("php://input"),true);

if (isset($bot['message'])) {
$chat_id = $bot['message']['chat']['id'];
$message = $bot['message']['text'];
$msgid = $bot['message']['message_id'];
if (strpos($message, '/') === 0) {
$message = str_replace("@$botu", '', $message);
trim($message);
        $com = explode(' ', $message);
        $comm = $com[0];
        $parameter = isset($com[1]) ? $com[1] : '';
        $params = isset($com[2]) ? $com[2] : '';
        $param = isset($com[3]) ? $com[3] : '';
       switch($comm){
       case '/start':
       sendMessage("*Welcome To @$botu\n  Check Out Our Featured Command:\n\n/start: To Start The Bot\n/cnv : For Converting Crypto To Inr \n/clc : For Converting Crypto To Inr\n/conv : For Converting Crypto To Inr\n/swap : For Converting Crypto To Inr\n/convert : For Converting Crypto To Inr\n/help : Help Related Issues*\n\n`To Use Our Bot In Your Group Click The Button Below 👇👇`",$chat_id,["inline_keyboard"=>[[["text"=>"🚀Add me to Group🚀","url"=>"https://t.me/$botu?startgroup=addtogroup"]]]],"markdown",$msgid);
       break;
       case '/help':
       sendMessage("_Contact @abhishek71599 regarding any problem_",$chat_id,null,'markdown',$msgid);
       break;
       case '/cnv':
       case '/convert':
       case '/clc':
       case '/conv':
       case '/swap':
       $params = $params == null?'inr':$params;
       $param = $param == null?'inr':$param;
       if(!is_numeric($parameter)||!$parameter){
       sendMessage("⚠️ Incorrect Format use\n`$comm 1 usdt inr`",$chat_id,null,"markdown",$msgid);
       return;}
       $price = json_decode(file_get_contents("https://api.coinconvert.net/convert/".strtolower($params)."/".strtolower($param)."?amount=$parameter"),true);
       if($price["status"] == "error"||$price == null){
       sendMessage("⚠️ This Action Is Not Support On [This Bot](https://t.me/$botu)",$chat_id,null,"markdown",$msgid);
       return;}
       $amount = $price[strtoupper($params)];
       $amount2 = $price[strtoupper($param)];
       sendMessage("`Calculating $amount $params`\n\n*🟢 $params/$param\n🔺 $amount $params : *`$amount2`* $param\n💹 1 $params ~ *`".($amount2/$amount)."` *$param*\n\n[Made By ](https://t.me/abhishek71599)",$chat_id,null,"markdown",$msgid);
       break;
       }}}
       
       
       function sendMessage($text,$chat_id,$inline=null,$parse=null,$msgid=null)
{

    $params = [
        'chat_id' => $chat_id,
        'text' => $text,
        'disable_web_page_preview'=>true,
        'reply_to_message_id'=>$msgid
    ];
if($inline){
$params['reply_markup'] = json_encode($inline);
}
if($parse){
$params['parse_mode'] = $parse;
}
    $url = "https://api.telegram.org/bot{$GLOBALS['token']}/sendMessage"; 

    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);
    file_put_contents("data.txt",$result);
    }
?>